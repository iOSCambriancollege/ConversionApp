package com.example.conversionapp;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private EditText inputedt1;
    private TextView resulttv1;
    private Spinner conversionspinner;
    private Button convertButton;

    private String selectConversion;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputedt1 = findViewById(R.id.inputedt1);
        resulttv1 = findViewById(R.id.resulttv1);
        conversionspinner = findViewById(R.id.conversionspinner);
        convertButton = findViewById(R.id.convertButton);

        conversionspinner.setOnItemSelectedListener(this);

        convertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                convert();
            }
        });
    }

    private void convert() {
        String inputValue = inputedt1.getText().toString();
        double input = Double.parseDouble(inputValue);

        double result;
        String resultdata;

        switch (selectConversion) {
            case "Centimeter to Inches":
                result = input * 0.393701;
                resultdata = input + " centimeter = " + result + " inches";
                break;
            case "Inches to Centimeter":
                result = input * 2.54;
                resultdata = input + " inches = " + result + " centimeter";
                break;
            case "Kilometer to Meter":
                result = input * 1000;
                resultdata = input + " kilometer = " + result + " meter";
                break;
            case "Meter to Kilometer":
                result = input / 1000;
                resultdata = input + " meter = " + result + " kilometer";
                break;
            case "Kilogram to Gram":
                result = input * 1000;
                resultdata = input + " kilogram = " + result + " gram";
                break;
            case "Gram to Kilogram":
                result = input / 1000;
                resultdata = input + " gram = " + result + " kilogram";
                break;
            default:
                resultdata = "Invalid conversion type";
                break;
        }

        resulttv1.setText(resultdata);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        selectConversion = parent.getItemAtPosition(position).toString();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        // Do nothing
    }
}
